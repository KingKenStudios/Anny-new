import React, { useState, useEffect } from 'react';
import { MobileLogoMenu } from './MobileLogoMenu';
import {
  Sparkles,
  Command,
  Camera,
  Globe,
  Volume2,
  Share2,
  ChevronDown,
  Bell,
  ShoppingBag,
  Code2,
  LayoutDashboard,
  Lock,
  Paperclip,
  AtSign,
  Mic,
  Send,
  Zap,
  Brain,
  Menu,
  BarChart3,
  Terminal,
  CheckCircle2,
  ArrowRight,
  Plus,
  RotateCcw,
  Copy,
  Check,
  ArrowLeft,
  Pencil,
  Monitor,
  Tablet,
  Smartphone,
  RefreshCw,
  Maximize2,
  Minimize2,
  X,
  Search,
  User,
  Heart,
  ShoppingCart,
  Truck,
  ShieldCheck,
  Headphones,
  RotateCw,
  Cpu,
  Layers,
  ExternalLink,
} from 'lucide-react';

import logoImg from './assets/logo.png';

const hardwareLogo = logoImg || '/logo.png';
import { AnnyVisualEditor } from './AnnyVisualEditor';
import { AnnyCodeExplorer } from './AnnyCodeExplorer';

interface AnnyWorkspaceProps {
  userEmail?: string;
  userName?: string;
  initialPrompt?: string;
  onToggleMobileMenu?: () => void;
}

export const AnnyWorkspace: React.FC<AnnyWorkspaceProps> = ({
  userEmail = 'amazonpromo234@gmail.com',
  userName = 'Akin Kehinde',
  initialPrompt,
  onToggleMobileMenu,
}) => {
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [activeMode, setActiveMode] = useState('builder');
  const [activeModel, setActiveModel] = useState('G-Ai (Default)');
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState('08:14 PM');
  
  // Mode toggle: true = split screen view (Prompt + Telemetry + Live Preview)
  const [isSplitScreen, setIsSplitScreen] = useState(false);
  // Mobile tab toggle for split view on mobile/tablet (chat vs preview)
  const [mobileSplitView, setMobileSplitView] = useState<'chat' | 'preview'>('preview');
  // Visual Studio / Manual AI Editor mode (Page 3 of Anny)
  const [isVisualEditor, setIsVisualEditor] = useState(false);
  const [previewTab, setPreviewTab] = useState<'preview' | 'code'>('preview');
  const [deviceViewport, setDeviceViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isFullscreenPreview, setIsFullscreenPreview] = useState(false);
  const [cartCount, setCartCount] = useState(3);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Close fullscreen on Escape key
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsFullscreenPreview(false);
      }
    };
    window.addEventListener('keydown', handleEscKey);
    return () => window.removeEventListener('keydown', handleEscKey);
  }, []);

  const [chatHistory, setChatHistory] = useState<
    Array<{
      id: string;
      role: 'user' | 'assistant';
      content: string;
      timestamp: string;
      codeSnippet?: string;
      steps?: string[];
    }>
  >([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Update clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const cardPrompts = [
    {
      id: 'ecommerce',
      icon: ShoppingBag,
      title: 'Build E-commerce Website',
      subtitle: 'Full-stack store with React & Tailwind',
    },
    {
      id: 'rest-api',
      icon: Code2,
      title: 'Create a REST API',
      subtitle: 'Secure Express API with authentication',
    },
    {
      id: 'dashboard',
      icon: LayoutDashboard,
      title: 'Design Dashboard UI',
      subtitle: 'Modern dark dashboard with analytics',
    },
    {
      id: 'supabase',
      icon: Lock,
      title: 'Set up Supabase Auth',
      subtitle: 'User login & database security rules',
    },
  ];

  const handleSend = (textToSend?: string) => {
    const messageText = textToSend || prompt;
    if (!messageText.trim() && !textToSend) return;

    const query = messageText || 'Build E-commerce Website';

    const userMsg = {
      id: Date.now().toString(),
      role: 'user' as const,
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatHistory((prev) => [...prev, userMsg]);
    setPrompt('');
    setIsGenerating(true);
    setIsSplitScreen(true); // Automatically trigger split screen mode!

    setTimeout(() => {
      let aiResponse = "I'll create a modern e-commerce platform with all the essential features you requested. Here's what I'll build for you:";
      let codeSnippet = `// E-commerce Storefront Configuration
import React from 'react';
import { ShoppingCart, Heart, Search } from 'lucide-react';

export default function StoreFront() {
  return (
    <div className="p-6 bg-slate-950 text-white rounded-2xl border border-white/10">
      <h2 className="text-xl font-bold">SHOPIX Storefront</h2>
      <p className="text-sm text-slate-400">Quantum-powered instant cart active.</p>
    </div>
  );
}`;
      let steps = [
        'Modern responsive UI with dark theme',
        'Product listing with search and filters',
        'Shopping cart and wishlist',
        'Secure checkout process',
        'User authentication and dashboard',
        'Order history and tracking',
      ];

      setChatHistory((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: aiResponse,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          codeSnippet,
          steps,
        },
      ]);
      setIsGenerating(false);
    }, 800);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Categories for the live preview
  const categoriesList = [
    {
      id: 'electronics',
      name: 'Electronics',
      count: '120+ Products',
      img: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80',
    },
    {
      id: 'fashion',
      name: 'Fashion',
      count: '80+ Products',
      img: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&q=80',
    },
    {
      id: 'home',
      name: 'Home & Living',
      count: '65+ Products',
      img: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&q=80',
    },
    {
      id: 'beauty',
      name: 'Beauty',
      count: '45+ Products',
      img: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400&q=80',
    },
    {
      id: 'sports',
      name: 'Sports',
      count: '60+ Products',
      img: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=400&q=80',
    },
  ];

  if (isVisualEditor) {
    return (
      <AnnyVisualEditor
        userEmail={userEmail}
        userName={userName}
        onBackToWorkspace={() => {
          setIsVisualEditor(false);
          setIsSplitScreen(false);
        }}
        onBackToSplitView={() => setIsVisualEditor(false)}
      />
    );
  }

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-[#040614] text-slate-100 h-full w-full relative overflow-hidden select-none">
      {/* Background Ambient Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-600/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* ========================================================= */}
      {/* 1. SPLIT SCREEN BUILD VIEW (Matches User Reference Image) */}
      {/* ========================================================= */}
      {isSplitScreen ? (
        <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#040614]">
          {/* Top Header Bar for Split View */}
          <header className="px-3 sm:px-4 py-2 bg-[#060818] border-b border-white/10 flex flex-wrap items-center justify-between gap-2 sm:gap-4 z-20 shrink-0">
            <div className="flex items-center gap-2 sm:gap-3">
            <MobileLogoMenu onToggleMobileMenu={onToggleMobileMenu} />

              <button
                onClick={() => setIsSplitScreen(false)}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 px-2.5 sm:px-3 py-1.5 rounded-xl border border-white/10 transition-all cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5 text-slate-400" />
                <span className="hidden sm:inline">Back to Workspace</span>
                <span className="sm:hidden">Back</span>
              </button>

              <div className="h-4 w-px bg-white/10 hidden sm:block" />

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white tracking-wide truncate max-w-[140px] sm:max-w-none">
                  Building E-Commerce Website
                </span>
                <Pencil className="w-3 h-3 text-slate-400 hover:text-white cursor-pointer shrink-0" />
              </div>
            </div>

            {/* Mobile View Toggle Switcher (Chat vs Preview) */}
            <div className="flex lg:hidden items-center p-0.5 rounded-xl bg-slate-900/90 border border-white/10">
              <button
                onClick={() => setMobileSplitView('chat')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  mobileSplitView === 'chat'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                AI Chat
              </button>
              <button
                onClick={() => setMobileSplitView('preview')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  mobileSplitView === 'preview'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Preview / Code
              </button>
            </div>

            {/* Right Telemetry & Status */}
            <div className="flex items-center gap-2 sm:gap-3 text-xs">
              <div className="flex items-center gap-2 px-2 py-1 rounded-full bg-purple-950/60 border border-purple-500/30 text-purple-300 text-[10px] sm:text-[11px] font-semibold">
                <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                <span>AI Building</span>
              </div>

              <div className="hidden lg:flex items-center gap-3 text-[10px] font-mono text-slate-300 bg-white/5 px-2.5 py-1 rounded-lg border border-white/5">
                <span>
                  CPU <strong className="text-blue-400">16%</strong>
                </span>
                <span>
                  GPU <strong className="text-emerald-400">35%</strong>
                </span>
                <span>
                  RAM <strong className="text-purple-400">54%</strong>
                </span>
                <span className="text-slate-500">|</span>
                <span className="font-sans text-slate-200">{currentTime}</span>
              </div>

              <button className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 hidden sm:block">
                <Bell className="w-3.5 h-3.5" />
              </button>

              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white text-[10px] font-bold shadow-md">
                ∞
              </div>
            </div>
          </header>

          {/* Main 2-Column Split Workspace */}
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden min-h-0">
            {/* ---------------------------------------------------- */}
            {/* MIDDLE COLUMN: Chat Assistant & Build Telemetry (Left) */}
            {/* ---------------------------------------------------- */}
            <div className={`w-full lg:w-[420px] xl:w-[460px] bg-[#06081a] border-r border-white/10 flex flex-col h-full overflow-hidden shrink-0 ${
              mobileSplitView === 'chat' ? 'flex' : 'hidden lg:flex'
            }`}>
              {/* Chat Sub-Header */}
              <div className="px-4 py-2.5 bg-[#080b22] border-b border-white/10 flex items-center justify-between text-xs text-slate-300">
                <div className="flex items-center gap-2 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>AI Assistant</span>
                  <span className="text-[10px] text-emerald-400 font-normal">• Online</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <Volume2 className="w-3.5 h-3.5 hover:text-white cursor-pointer" />
                  <Copy className="w-3.5 h-3.5 hover:text-white cursor-pointer" />
                </div>
              </div>

              {/* Chat Scrollable Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-sans">
                {/* User Message */}
                <div className="flex flex-col items-end space-y-1">
                  <div className="text-[10px] text-slate-400 font-mono">
                    You <span className="text-slate-500">10:42 AM</span>
                  </div>
                  <div className="bg-indigo-950/80 border border-indigo-500/30 text-indigo-100 rounded-2xl rounded-tr-sm p-3 max-w-[88%] shadow-md leading-relaxed">
                    Generate a modern e-commerce platform with product listing, cart, checkout and user dashboard.
                  </div>
                </div>

                {/* AI Assistant Message */}
                <div className="flex flex-col items-start space-y-1">
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono">
                    <div className="w-4 h-4 rounded bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-[8px] font-bold text-white">
                      A
                    </div>
                    <span className="text-white font-semibold">AIOS</span>
                    <span className="text-slate-500">10:42 AM</span>
                  </div>

                  <div className="bg-[#0b0e29] border border-white/10 rounded-2xl rounded-tl-sm p-3.5 space-y-3 w-full text-slate-200">
                    <p className="leading-relaxed">
                      I'll create a modern e-commerce platform with all the essential features you requested. Here's what I'll build for you:
                    </p>

                    <div className="space-y-1.5 pt-1">
                      {[
                        'Modern responsive UI with dark theme',
                        'Product listing with search and filters',
                        'Shopping cart and wishlist',
                        'Secure checkout process',
                        'User authentication and dashboard',
                        'Order history and tracking',
                      ].map((item, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span className="text-slate-300">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Live Build Progress Card (Phase Card) */}
                <div className="bg-[#0a0d2a] border border-indigo-500/30 rounded-2xl p-4 space-y-3 shadow-lg relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs">Building Your E-Commerce Platform</span>
                    <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-[10px] font-semibold">
                      Phase 3 of 6
                    </span>
                  </div>

                  {/* Step Pipeline Dots */}
                  <div className="flex items-center justify-between py-2 text-[9px] font-semibold text-slate-400 border-y border-white/5">
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500 text-emerald-400 flex items-center justify-center text-[10px]">
                        ✓
                      </div>
                      <span>Planning</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500 text-emerald-400 flex items-center justify-center text-[10px]">
                        ✓
                      </div>
                      <span>Designing UI</span>
                    </div>

                    <div className="flex flex-col items-center gap-1">
                      <div className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[9px] font-bold shadow-[0_0_10px_rgba(168,85,247,0.8)]">
                        &lt;/&gt;
                      </div>
                      <span className="text-purple-300">Building Frontend</span>
                    </div>

                    <div className="flex flex-col items-center gap-1 opacity-50">
                      <div className="w-5 h-5 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-[10px]">
                        ⚙
                      </div>
                      <span>Integrating Backend</span>
                    </div>

                    <div className="flex flex-col items-center gap-1 opacity-50">
                      <div className="w-5 h-5 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-[10px]">
                        🧪
                      </div>
                      <span>Testing</span>
                    </div>

                    <div className="flex flex-col items-center gap-1 opacity-50">
                      <div className="w-5 h-5 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-[10px]">
                        🚀
                      </div>
                      <span>Deployment</span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-medium">
                      <span className="text-slate-300">Generating Product Listing Page...</span>
                      <span className="text-cyan-400 font-bold">58%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                      <div className="h-full w-[58%] bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 rounded-full animate-pulse" />
                    </div>
                  </div>

                  {/* Live Terminal Console Log Box */}
                  <div className="bg-[#050718] rounded-xl border border-white/10 p-2.5 font-mono text-[10px] space-y-1 text-slate-300">
                    <div className="flex items-center justify-between text-slate-400">
                      <span>10:44:12 Creating responsive product grid...</span>
                      <span className="text-emerald-400">✓</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400">
                      <span>10:44:15 Implementing filter and search...</span>
                      <span className="text-emerald-400">✓</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400">
                      <span>10:44:18 Adding product cards and pagination...</span>
                      <span className="text-emerald-400">✓</span>
                    </div>
                    <div className="flex items-center justify-between text-cyan-300">
                      <span>10:44:21 Optimizing images and performance...</span>
                      <span className="animate-spin">↻</span>
                    </div>
                  </div>

                  {/* Telemetry Numbers Matrix */}
                  <div className="grid grid-cols-5 gap-1 pt-1 text-center font-mono">
                    <div className="bg-white/5 rounded p-1">
                      <p className="text-[8px] text-slate-400">Files Created</p>
                      <p className="text-xs font-bold text-white">24</p>
                    </div>
                    <div className="bg-white/5 rounded p-1">
                      <p className="text-[8px] text-slate-400">Components</p>
                      <p className="text-xs font-bold text-white">18</p>
                    </div>
                    <div className="bg-white/5 rounded p-1">
                      <p className="text-[8px] text-slate-400">Functions</p>
                      <p className="text-xs font-bold text-white">37</p>
                    </div>
                    <div className="bg-white/5 rounded p-1">
                      <p className="text-[8px] text-slate-400">Lines of Code</p>
                      <p className="text-xs font-bold text-white">2,842</p>
                    </div>
                    <div className="bg-white/5 rounded p-1">
                      <p className="text-[8px] text-slate-400">Time Elapsed</p>
                      <p className="text-xs font-bold text-cyan-400">02:34</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Chat Bottom Input Section */}
              <div className="p-3 bg-[#080b22] border-t border-white/10 space-y-2 shrink-0">
                <div className="relative flex items-center bg-[#0d1130] rounded-xl border border-white/10 p-2 focus-within:border-indigo-500">
                  <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Ask anything or describe what you want to build..."
                    className="w-full bg-transparent border-none outline-none text-xs text-white placeholder-slate-400 pr-8"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (prompt.trim()) {
                        handleSend();
                      } else {
                        handleSend('Build E-commerce Website with REST API');
                      }
                    }}
                    disabled={isGenerating}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 cursor-pointer shadow-md transition-all ${
                      prompt.trim()
                        ? 'bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-600 text-white shadow-[0_0_12px_rgba(99,102,241,0.5)] hover:scale-105'
                        : 'bg-indigo-950/80 hover:bg-indigo-900/90 text-cyan-400 border border-indigo-500/40 hover:scale-105'
                    }`}
                    title={prompt.trim() ? "Send message" : "Voice input / Mic"}
                  >
                    {prompt.trim() ? (
                      <Send className="w-3.5 h-3.5" />
                    ) : (
                      <Mic className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
                    )}
                  </button>
                </div>

                {/* Action Chips */}
                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 flex items-center gap-1 hover:text-white cursor-pointer">
                      <Paperclip className="w-2.5 h-2.5" /> Attach Files
                    </span>
                    <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 flex items-center gap-1 hover:text-white cursor-pointer">
                      <Globe className="w-2.5 h-2.5" /> Web Search
                    </span>
                    <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 flex items-center gap-1 hover:text-white cursor-pointer">
                      <Brain className="w-2.5 h-2.5" /> AI Model
                    </span>
                    <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 flex items-center gap-1 hover:text-white cursor-pointer">
                      <Code2 className="w-2.5 h-2.5" /> Code Context
                    </span>
                  </div>
                </div>

                {/* Model & Tokens Footer bar */}
                <div className="flex items-center justify-between text-[9px] text-slate-400 pt-1 border-t border-white/5 font-mono">
                  <span>AIOS Model: <strong className="text-slate-200">Akin Core 2.0 ∨</strong></span>
                  <span>Memory: <strong className="text-emerald-400">Active</strong></span>
                  <span>Context: <strong className="text-slate-200">E-Commerce Platform ∨</strong></span>
                  <span>Tokens: <strong className="text-slate-200">12,450</strong></span>
                </div>
              </div>
            </div>

            {/* ---------------------------------------------------- */}
            {/* RIGHT COLUMN: Live Interactive App Preview / IDE      */}
            {/* ---------------------------------------------------- */}
            <div className={`flex-1 bg-[#030511] flex-col h-full overflow-hidden min-w-0 ${
              mobileSplitView === 'preview' ? 'flex' : 'hidden lg:flex'
            }`}>
              {/* Preview Controls Top Bar */}
              <div className="px-4 py-2 bg-[#060818] border-b border-white/10 flex items-center justify-between gap-4 z-10 shrink-0">
                {/* Left Tabs */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPreviewTab('preview')}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      previewTab === 'preview'
                        ? 'bg-indigo-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>Preview</span>
                  </button>

                  <button
                    onClick={() => setPreviewTab('code')}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      previewTab === 'code'
                        ? 'bg-indigo-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Code2 className="w-3.5 h-3.5" />
                    <span>Code</span>
                  </button>

                  <button
                    onClick={() => setIsVisualEditor(true)}
                    className="px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md hover:brightness-110"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    <span>Visual Edit</span>
                  </button>
                </div>

                {/* Center Device Responsive Toggles */}
                <div className="flex items-center gap-1 bg-[#0a0d28] p-1 rounded-lg border border-white/10">
                  <button
                    onClick={() => setDeviceViewport('desktop')}
                    className={`p-1 rounded ${deviceViewport === 'desktop' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Monitor className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeviceViewport('tablet')}
                    className={`p-1 rounded ${deviceViewport === 'tablet' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Tablet className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeviceViewport('mobile')}
                    className={`p-1 rounded ${deviceViewport === 'mobile' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Right Action Buttons */}
                <div className="flex items-center gap-2">
                  <button className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10">
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>

                  <button className="px-3 py-1 rounded-lg bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white font-semibold text-xs shadow-md hover:brightness-110 flex items-center gap-1">
                    <span>Deploy</span>
                    <ChevronDown className="w-3 h-3" />
                  </button>

                  <button
                    onClick={() => setIsFullscreenPreview(true)}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs flex items-center gap-1 border border-white/10 cursor-pointer hover:border-indigo-500/50 hover:text-white transition-all shadow-sm"
                  >
                    <Maximize2 className="w-3 h-3 text-indigo-400" />
                    <span className="hidden sm:inline">Fullscreen</span>
                  </button>
                </div>
              </div>

              {/* Main Content Stage */}
              <div className="flex-1 overflow-y-auto p-4 flex items-center justify-center min-h-0 bg-[#02030d]">
                <div
                  className={`transition-all duration-300 h-full w-full bg-[#07091e] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden ${
                    deviceViewport === 'mobile'
                      ? 'max-w-sm h-[650px]'
                      : deviceViewport === 'tablet'
                      ? 'max-w-2xl h-[700px]'
                      : 'w-full h-full'
                  }`}
                >
                  {previewTab === 'preview' ? (
                    /* SHOPIX E-Commerce Application Live Store */
                    <div className="flex-1 flex flex-col overflow-y-auto bg-[#080b22] text-slate-100 font-sans relative">
                      {/* Global AI Backend Connect Alert Notice */}
                      <div className="bg-amber-500/20 border-b border-amber-500/40 px-4 py-2 flex items-center justify-between text-xs text-amber-200 z-30">
                        <div className="flex items-center gap-2 font-medium">
                          <span className="px-1.5 py-0.5 rounded bg-amber-500 text-black font-extrabold text-[10px] uppercase tracking-wider">
                            UI MOCKUP
                          </span>
                          <span>Frontend Standalone Preview — [AI Directive: Replace all static state with real backend API & Database]</span>
                        </div>
                        <span className="text-[10px] text-amber-300/80 font-mono hidden sm:inline-block">Backend: Disconnected</span>
                      </div>

                      {/* Store Header Navigation */}
                      <header className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-[#080b22]/90 sticky top-0 z-20 backdrop-blur-md">
                        <div className="flex items-center gap-2">
                          <ShoppingBag className="w-5 h-5 text-indigo-400" />
                          <span className="text-lg font-black tracking-wider text-white">SHOPIX</span>
                        </div>

                        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
                          <a href="#home" className="text-white font-bold">Home</a>
                          <a href="#shop" className="hover:text-white">Shop</a>
                          <a href="#categories" className="hover:text-white">Categories</a>
                          <a href="#deals" className="hover:text-white">Deals</a>
                          <a href="#about" className="hover:text-white">About</a>
                        </nav>

                        <div className="flex items-center gap-4 text-slate-300">
                          <Search className="w-4 h-4 hover:text-white cursor-pointer" />
                          <User className="w-4 h-4 hover:text-white cursor-pointer" />
                          <Heart className="w-4 h-4 hover:text-white cursor-pointer" />
                          <div className="relative cursor-pointer" onClick={() => setCartCount(cartCount + 1)}>
                            <ShoppingCart className="w-4 h-4 hover:text-white" />
                            <span className="absolute -top-1.5 -right-2 bg-purple-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                              {cartCount}
                            </span>
                          </div>
                        </div>
                      </header>

                      {/* SHOPIX Hero Section */}
                      <div className="p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-blue-950/30">
                        <div className="space-y-4">
                          <span className="px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 text-[10px] font-bold uppercase tracking-widest">
                            NEW COLLECTION
                          </span>
                          <h1 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight">
                            Discover Amazing <span className="bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-400 text-transparent bg-clip-text">Products</span>
                          </h1>
                          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-md">
                            Shop the latest collections with unbeatable prices and exceptional quality.
                          </p>
                          <div className="flex items-center gap-3 pt-2">
                            <button
                              onClick={() => setCartCount(cartCount + 1)}
                              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-[0_0_20px_rgba(168,85,247,0.4)] transition-all cursor-pointer"
                            >
                              Shop Now
                            </button>
                            <button className="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 border border-white/15 font-semibold text-xs transition-all cursor-pointer">
                              Explore Deals
                            </button>
                          </div>
                        </div>

                        {/* Floating Sleek Headphones Image with Halo Ring */}
                        <div className="relative flex items-center justify-center">
                          <div className="absolute w-56 h-56 sm:w-64 sm:h-64 rounded-full border-2 border-purple-500/60 shadow-[0_0_50px_rgba(168,85,247,0.5)] animate-pulse" />
                          <img
                            src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80"
                            alt="Wireless Headphone"
                            referrerPolicy="no-referrer"
                            className="w-52 h-52 sm:w-60 sm:h-60 object-contain relative z-10 filter drop-shadow-[0_20px_30px_rgba(0,0,0,0.8)]"
                          />
                        </div>
                      </div>

                      {/* Feature Highlights Banner */}
                      <div className="px-6 py-4 grid grid-cols-1 sm:grid-cols-3 gap-4 border-y border-white/10 bg-[#06081c]">
                        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                          <Truck className="w-5 h-5 text-indigo-400" />
                          <div>
                            <p className="text-xs font-bold text-white">Free Shipping</p>
                            <p className="text-[10px] text-slate-400">On orders over $100</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                          <ShieldCheck className="w-5 h-5 text-purple-400" />
                          <div>
                            <p className="text-xs font-bold text-white">Secure Payment</p>
                            <p className="text-[10px] text-slate-400">100% secure checkout</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                          <Headphones className="w-5 h-5 text-cyan-400" />
                          <div>
                            <p className="text-xs font-bold text-white">24/7 Support</p>
                            <p className="text-[10px] text-slate-400">Always here to help</p>
                          </div>
                        </div>
                      </div>

                      {/* Category Grid Section */}
                      <div className="p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <h2 className="text-base font-bold text-white">Shop by Categories</h2>
                          <a href="#all" className="text-xs text-indigo-400 hover:underline">View All</a>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                          {categoriesList.map((cat) => (
                            <div
                              key={cat.id}
                              onClick={() => setSelectedCategory(cat.name)}
                              className={`bg-[#0b0f30] border rounded-2xl p-3 flex flex-col items-center text-center cursor-pointer transition-all hover:scale-[1.03] group ${
                                selectedCategory === cat.name
                                  ? 'border-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.5)]'
                                  : 'border-white/10 hover:border-white/20'
                              }`}
                            >
                              <div className="w-20 h-20 rounded-xl overflow-hidden mb-2 bg-slate-900">
                                <img
                                  src={cat.img}
                                  alt={cat.name}
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                                />
                              </div>
                              <p className="text-xs font-bold text-white leading-tight">{cat.name}</p>
                              <p className="text-[10px] text-slate-400">{cat.count}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* IDE Code Tab View with File & Folder Explorer */
                    <AnnyCodeExplorer />
                  )}
                </div>
              </div>

              {/* Bottom Preview Status Bar */}
              <div className="px-4 py-1.5 bg-[#060818] border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400 shrink-0 font-mono">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    Responsive
                  </span>
                  <span className="flex items-center gap-1 text-cyan-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    Ready
                  </span>
                </div>

                <div className="flex items-center gap-4">
                  <span>☁️ Auto-saving...</span>
                  <span>Last updated: 2s ago</span>
                  <span className="px-2 py-0.5 rounded-full bg-purple-950 border border-purple-500/40 text-purple-300 font-semibold font-sans">
                    • Live Preview
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ========================================================= */
        /* 2. STANDARD FULL Anny WORKSPACE PAGE                    */
        /* ========================================================= */
        <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
          {/* TOP UNIFIED HEADER BAR (Clean Transparent Background) */}
          <header className="px-4 sm:px-6 py-3 bg-transparent flex items-center justify-between gap-3 sticky top-0 z-30 shrink-0">
            {/* Left side: Mobile Animated Logo Menu */}
            <div className="flex items-center gap-3">
              <MobileLogoMenu onToggleMobileMenu={onToggleMobileMenu} />
            </div>

            {/* Right side: Vision Monitor, Globe, Model Selector, and User Icon */}
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <button className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 flex items-center gap-1.5 transition-all cursor-pointer text-xs backdrop-blur-sm">
                <Camera className="w-3.5 h-3.5 text-indigo-400" />
                <span>Vision Monitor</span>
              </button>

              <button className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 transition-all cursor-pointer backdrop-blur-sm">
                <Globe className="w-3.5 h-3.5 text-slate-300" />
              </button>

              {/* Model Selector Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setIsModelDropdownOpen(!isModelDropdownOpen)}
                  className="px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 flex items-center gap-2 transition-all cursor-pointer text-xs font-semibold backdrop-blur-sm"
                >
                  <span>{activeModel}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {isModelDropdownOpen && (
                  <div className="absolute right-0 mt-1 w-48 bg-[#0c1028]/95 backdrop-blur-xl border border-white/15 rounded-xl shadow-2xl p-1.5 z-50 space-y-0.5 text-xs">
                    {['G-Ai (Default)', 'G-Ai Pro 1.5', 'G-Ai Code Ultra', 'Claude 3.5 Sonnet'].map((model) => (
                      <button
                        key={model}
                        onClick={() => {
                          setActiveModel(model);
                          setIsModelDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-colors ${
                          activeModel === model
                            ? 'bg-indigo-600/30 text-cyan-300 border border-indigo-500/40'
                            : 'text-slate-300 hover:bg-white/5'
                        }`}
                      >
                        {model}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* User Profile Avatar Beside Model Menu */}
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 border border-indigo-400/50 flex items-center justify-center text-white font-bold text-xs shadow-md shrink-0 ml-1">
                {userName ? userName.charAt(0).toUpperCase() : 'A'}
              </div>
            </div>
          </header>

          {/* MAIN SCROLLABLE WRAPPER (Scrollbar positioned at far right edge) */}
          <div className="flex-1 w-full overflow-y-auto custom-scrollbar flex flex-col justify-between min-h-0">
            <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-2 flex flex-col items-center justify-center z-10 min-h-0">
              {/* INITIAL HERO DISPLAY */}
              <div className="flex-1 flex flex-col items-center justify-center text-center my-auto py-2 sm:py-4 space-y-3 sm:space-y-5">
                {/* Hardware Logo Display */}
              <div className="relative group cursor-pointer flex items-center justify-center" onClick={() => handleSend('Build E-commerce Website')}>
                <img
                  src={hardwareLogo}
                  alt="Hardware Logo - Anny"
                  loading="eager"
                  fetchpriority="high"
                  decoding="sync"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.dataset.tried) {
                      target.dataset.tried = 'true';
                      target.src = '/logo.png';
                    }
                  }}
                  className="h-16 sm:h-20 lg:h-24 w-auto object-contain filter drop-shadow-[0_0_20px_rgba(0,229,255,0.6)] group-hover:scale-105 transition-transform duration-300"
                />
              </div>

              {/* Title & Subtitle */}
              <div className="space-y-1.5 max-w-2xl">
                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight font-heading animate-aios-shift">
                  Anny
                </h1>
                <p className="text-xs sm:text-sm lg:text-base text-slate-300 font-medium tracking-wide">
                  Your All-in-One AI Developer Assistant
                </p>
              </div>

              {/* Quick Action Prompt Cards (Hidden on Mobile & Tablet Mode) */}
              <div className="hidden lg:grid lg:grid-cols-4 gap-3 sm:gap-4 w-full pt-2 sm:pt-3 max-w-4xl">
                {cardPrompts.map((card) => {
                  const IconComp = card.icon;
                  return (
                    <button
                      key={card.id}
                      onClick={() => handleSend(card.title)}
                      className="bg-[#0b0f2d]/90 hover:bg-[#121742] border border-white/10 hover:border-indigo-500/50 rounded-2xl p-4 text-left transition-all duration-200 cursor-pointer group shadow-lg flex flex-col justify-between hover:shadow-[0_0_25px_rgba(99,102,241,0.25)]"
                    >
                      <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform mb-3">
                        <IconComp className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                          {card.title}
                        </h3>
                        <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                          {card.subtitle}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </main>
          </div>

          {/* ANCHORED CHAT BOX (Stands completely still at bottom) */}
          <div className="shrink-0 w-full max-w-3xl mx-auto px-4 pb-4 sm:pb-6 pt-2 z-20">
            <div className="bg-[#0b0f2d]/90 border border-white/15 rounded-2xl p-2.5 sm:p-3 shadow-[0_10px_30px_rgba(0,0,0,0.5)] focus-within:border-indigo-500/80 focus-within:ring-2 focus-within:ring-indigo-500/30 transition-all backdrop-blur-md">
              <div className="flex items-center gap-2 px-2">
                <input
                  type="text"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask Anny to build an app, website, or generate code..."
                  className="w-full bg-transparent border-none outline-none text-xs sm:text-sm text-white placeholder-slate-400 py-1"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (prompt.trim()) {
                      handleSend();
                    } else {
                      handleSend('Build E-commerce Website with REST API');
                    }
                  }}
                  disabled={isGenerating}
                  className={`p-2 sm:p-2.5 rounded-xl flex items-center justify-center shrink-0 transition-all cursor-pointer ${
                    prompt.trim()
                      ? 'bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-600 text-white shadow-[0_0_15px_rgba(99,102,241,0.5)] hover:scale-105'
                      : 'bg-indigo-600/30 hover:bg-indigo-600/50 text-cyan-400 border border-indigo-500/40 hover:scale-105'
                  }`}
                  title={prompt.trim() ? "Send message" : "Voice input / Mic"}
                >
                  {prompt.trim() ? (
                    <Send className="w-4 h-4" />
                  ) : (
                    <Mic className="w-4 h-4 text-cyan-300 animate-pulse" />
                  )}
                </button>
              </div>

              {/* Bottom Chips */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-white/5 mt-2 px-1">
                <div className="flex items-center gap-2">
                  <button className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer">
                    <Paperclip className="w-3 h-3" />
                    <span>Attach</span>
                  </button>
                  <button className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer">
                    <Globe className="w-3 h-3" />
                    <span>Web</span>
                  </button>
                  <button className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer">
                    <Zap className="w-3 h-3 text-amber-400" />
                    <span>Pro Tools</span>
                  </button>
                </div>

                <span className="text-[10px] text-slate-500 font-mono">
                  Press Enter to build
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FULLSCREEN LIVE PREVIEW MODAL */}
      {isFullscreenPreview && (
        <div className="fixed inset-0 z-[100] bg-[#02030e] flex flex-col w-screen h-screen overflow-hidden">
          {/* Top Header Bar */}
          <div className="px-4 sm:px-6 py-3 bg-[#060818] border-b border-white/10 flex items-center justify-between gap-4 shrink-0 z-20">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <span className="text-sm font-extrabold text-white tracking-wide truncate font-heading">
                  SHOPIX E-Commerce Application — Live Fullscreen
                </span>
              </div>
              <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-[10px] font-bold uppercase tracking-wider shrink-0">
                Fullscreen Mode
              </span>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              {/* Responsive Device Viewport Switcher */}
              <div className="flex items-center gap-1 bg-[#0a0d28] p-1 rounded-lg border border-white/10">
                <button
                  onClick={() => setDeviceViewport('desktop')}
                  className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    deviceViewport === 'desktop' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Desktop</span>
                </button>
                <button
                  onClick={() => setDeviceViewport('tablet')}
                  className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    deviceViewport === 'tablet' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Tablet className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Tablet</span>
                </button>
                <button
                  onClick={() => setDeviceViewport('mobile')}
                  className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    deviceViewport === 'mobile' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Mobile</span>
                </button>
              </div>

              {/* View Tab Switcher */}
              <div className="flex items-center gap-1 bg-[#0a0d28] p-1 rounded-lg border border-white/10">
                <button
                  onClick={() => setPreviewTab('preview')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    previewTab === 'preview' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Preview
                </button>
                <button
                  onClick={() => setPreviewTab('code')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                    previewTab === 'code' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Code
                </button>
              </div>

              {/* Close Fullscreen Button */}
              <button
                onClick={() => setIsFullscreenPreview(false)}
                className="px-3.5 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 hover:text-red-100 text-xs font-bold border border-red-500/40 flex items-center gap-1.5 transition-all cursor-pointer shadow-lg"
              >
                <Minimize2 className="w-4 h-4" />
                <span>Exit Fullscreen</span>
              </button>
            </div>
          </div>

          {/* Fullscreen Body Stage */}
          <div className="flex-1 p-2 sm:p-4 bg-[#01020a] flex items-center justify-center overflow-hidden min-h-0">
            <div
              className={`transition-all duration-300 h-full w-full bg-[#080b22] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden ${
                deviceViewport === 'mobile'
                  ? 'max-w-sm h-[90vh]'
                  : deviceViewport === 'tablet'
                  ? 'max-w-3xl h-[92vh]'
                  : 'w-full h-full'
              }`}
            >
              {previewTab === 'preview' ? (
                /* SHOPIX E-Commerce Application Live Store Fullscreen */
                <div className="flex-1 flex flex-col overflow-y-auto bg-[#080b22] text-slate-100 font-sans custom-scrollbar">
                  {/* Store Header Navigation */}
                  <header className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-[#080b22]/90 sticky top-0 z-20 backdrop-blur-md">
                    <div className="flex items-center gap-2">
                      <ShoppingBag className="w-6 h-6 text-indigo-400" />
                      <span className="text-xl font-black tracking-wider text-white font-heading">SHOPIX</span>
                    </div>

                    <nav className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-300">
                      <a href="#home" className="text-white font-bold">Home</a>
                      <a href="#shop" className="hover:text-white transition-colors">Shop</a>
                      <a href="#categories" className="hover:text-white transition-colors">Categories</a>
                      <a href="#deals" className="hover:text-white transition-colors">Deals</a>
                      <a href="#about" className="hover:text-white transition-colors">About Us</a>
                    </nav>

                    <div className="flex items-center gap-5 text-slate-300">
                      <Search className="w-4 h-4 hover:text-white cursor-pointer transition-colors" />
                      <User className="w-4 h-4 hover:text-white cursor-pointer transition-colors" />
                      <Heart className="w-4 h-4 hover:text-white cursor-pointer transition-colors" />
                      <div className="relative cursor-pointer" onClick={() => setCartCount(cartCount + 1)}>
                        <ShoppingCart className="w-5 h-5 hover:text-white transition-colors" />
                        <span className="absolute -top-1.5 -right-2 bg-purple-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                          {cartCount}
                        </span>
                      </div>
                    </div>
                  </header>

                  {/* SHOPIX Hero Section */}
                  <div className="p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-2 gap-10 items-center bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-blue-950/30">
                    <div className="space-y-5">
                      <span className="px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 text-[10px] font-bold uppercase tracking-widest">
                        NEW COLLECTION
                      </span>
                      <h1 className="text-4xl sm:text-5xl font-black text-white leading-tight font-heading">
                        Discover Amazing <span className="bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-400 text-transparent bg-clip-text">Products</span>
                      </h1>
                      <p className="text-sm text-slate-300 leading-relaxed max-w-lg">
                        Shop the latest tech, fashion, and lifestyle collections with unbeatable prices and exceptional quality.
                      </p>
                      <div className="flex items-center gap-4 pt-2">
                        <button
                          onClick={() => setCartCount(cartCount + 1)}
                          className="px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm shadow-[0_0_25px_rgba(168,85,247,0.5)] transition-all cursor-pointer hover:scale-105"
                        >
                          Shop Now
                        </button>
                        <button className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 border border-white/15 font-semibold text-sm transition-all cursor-pointer">
                          Explore Deals
                        </button>
                      </div>
                    </div>

                    {/* Hero Product Image */}
                    <div className="relative flex items-center justify-center">
                      <div className="absolute w-64 h-64 sm:w-72 sm:h-72 rounded-full border-2 border-purple-500/60 shadow-[0_0_60px_rgba(168,85,247,0.5)] animate-pulse" />
                      <img
                        src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80"
                        alt="Wireless Headphone"
                        referrerPolicy="no-referrer"
                        className="w-60 h-60 sm:w-72 sm:h-72 object-contain relative z-10 filter drop-shadow-[0_25px_35px_rgba(0,0,0,0.8)]"
                      />
                    </div>
                  </div>

                  {/* Feature Highlights Banner */}
                  <div className="px-8 py-5 grid grid-cols-1 sm:grid-cols-3 gap-6 border-y border-white/10 bg-[#06081c]">
                    <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/5">
                      <Truck className="w-6 h-6 text-indigo-400" />
                      <div>
                        <p className="text-sm font-bold text-white">Free Shipping</p>
                        <p className="text-xs text-slate-400">On all worldwide orders over $100</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/5">
                      <ShieldCheck className="w-6 h-6 text-purple-400" />
                      <div>
                        <p className="text-sm font-bold text-white">Secure Payment</p>
                        <p className="text-xs text-slate-400">100% encrypted & safe checkout</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/5">
                      <Headphones className="w-6 h-6 text-cyan-400" />
                      <div>
                        <p className="text-sm font-bold text-white">24/7 Expert Support</p>
                        <p className="text-xs text-slate-400">Instant dedicated assistance</p>
                      </div>
                    </div>
                  </div>

                  {/* Category Grid Section */}
                  <div className="p-8 space-y-5">
                    <div className="flex items-center justify-between">
                      <h2 className="text-lg font-bold text-white font-heading">Shop by Categories</h2>
                      <a href="#all" className="text-xs text-indigo-400 hover:underline font-semibold">View All Categories →</a>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                      {categoriesList.map((cat) => (
                        <div
                          key={cat.id}
                          onClick={() => setSelectedCategory(cat.name)}
                          className={`bg-[#0b0f30] border rounded-2xl p-4 flex flex-col items-center text-center cursor-pointer transition-all hover:scale-[1.03] group ${
                            selectedCategory === cat.name
                              ? 'border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.5)]'
                              : 'border-white/10 hover:border-white/25'
                          }`}
                        >
                          <div className="w-24 h-24 rounded-xl overflow-hidden mb-3 bg-slate-900">
                            <img
                              src={cat.img}
                              alt={cat.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            />
                          </div>
                          <p className="text-sm font-bold text-white leading-tight">{cat.name}</p>
                          <p className="text-xs text-slate-400 mt-1">{cat.count}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* IDE Code View Fullscreen with File & Folder Explorer */
                <AnnyCodeExplorer />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
