import React, { useState } from 'react';
import { AnnyWorkspace } from './AnnyWorkspace';
import { AnnyProjectsView } from './views/AnnyProjectsView';
import { AnnySessionHistoryView } from './views/AnnySessionHistoryView';
import { AnnyAgentsView } from './views/AnnyAgentsView';
import { AnnyKnowledgeView } from './views/AnnyKnowledgeView';
import { AnnyMemoryView } from './views/AnnyMemoryView';
import { AnnyPromptsView } from './views/AnnyPromptsView';
import { AnnyModelsView } from './views/AnnyModelsView';
import { AnnyToolsView } from './views/AnnyToolsView';
import { AnnyIntegrationsView } from './views/AnnyIntegrationsView';
import { AnnySettingsView } from './views/AnnySettingsView';
import { AnnySlideMenu } from './AnnySlideMenu';

interface AnnyAppProps {
  userEmail?: string;
  userName?: string;
  activeSubTab?: string;
  onToggleMobileMenu?: () => void;
  onSelectSubTab?: (subTab: string) => void;
}

export const AnnyApp: React.FC<AnnyAppProps> = ({
  userEmail = 'amazonpromo234@gmail.com',
  userName = 'Akin Kehinde',
  activeSubTab = 'anny',
  onToggleMobileMenu,
  onSelectSubTab,
}) => {
  const [internalTab, setInternalTab] = useState<string>(activeSubTab);
  const [activePromptHint, setActivePromptHint] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Synchronize prop changes if parent passes a subTab
  const currentTab = activeSubTab || internalTab;

  const handleTabChange = (tab: string) => {
    setInternalTab(tab);
    if (onSelectSubTab) {
      onSelectSubTab(tab);
    }
  };

  const handleOpenChatWithPrompt = (promptText: string) => {
    setActivePromptHint(promptText);
    handleTabChange('chats');
  };

  const handleToggleMenu = () => {
    setIsMobileMenuOpen((prev) => !prev);
    if (onToggleMobileMenu) {
      onToggleMobileMenu();
    }
  };

  const renderActiveView = () => {
    if (currentTab === 'projects' || currentTab === 'anny-projects') {
      return (
        <AnnyProjectsView
          onToggleMobileMenu={handleToggleMenu}
          onOpenChatWithProject={(projName) =>
            handleOpenChatWithPrompt(`Open project ${projName} and analyze architectural components.`)
          }
        />
      );
    }

    if (currentTab === 'session-history' || currentTab === 'history' || currentTab === 'anny-history') {
      return (
        <AnnySessionHistoryView
          onToggleMobileMenu={handleToggleMenu}
          onSelectSession={() => handleTabChange('chats')}
        />
      );
    }

    if (currentTab === 'ai-agents' || currentTab === 'agents' || currentTab === 'anny-agents') {
      return (
        <AnnyAgentsView
          onToggleMobileMenu={handleToggleMenu}
          onOpenAgent={(agentName) =>
            handleOpenChatWithPrompt(`Activate agent ${agentName} for this workspace.`)
          }
        />
      );
    }

    if (currentTab === 'knowledge' || currentTab === 'knowledge-base' || currentTab === 'anny-knowledge') {
      return <AnnyKnowledgeView onToggleMobileMenu={handleToggleMenu} />;
    }

    if (currentTab === 'memory' || currentTab === 'anny-memory') {
      return <AnnyMemoryView onToggleMobileMenu={handleToggleMenu} />;
    }

    if (currentTab === 'prompt-library' || currentTab === 'prompts' || currentTab === 'anny-prompts') {
      return <AnnyPromptsView onToggleMobileMenu={handleToggleMenu} onUsePrompt={handleOpenChatWithPrompt} />;
    }

    if (currentTab === 'models' || currentTab === 'anny-models') {
      return (
        <AnnyModelsView
          onToggleMobileMenu={handleToggleMenu}
          onSelectModel={() => handleTabChange('chats')}
        />
      );
    }

    if (currentTab === 'tools' || currentTab === 'anny-tools') {
      return (
        <AnnyToolsView
          onToggleMobileMenu={handleToggleMenu}
          onOpenTool={(toolName, hint) =>
            handleOpenChatWithPrompt(hint || `Launch ${toolName} tool.`)
          }
        />
      );
    }

    if (currentTab === 'integrations' || currentTab === 'anny-integrations') {
      return <AnnyIntegrationsView onToggleMobileMenu={handleToggleMenu} />;
    }

    if (currentTab === 'settings' || currentTab === 'anny-settings') {
      return <AnnySettingsView onToggleMobileMenu={handleToggleMenu} />;
    }

    // Default / Chats / New Chat -> Primary Anny Chat & Builder Workspace
    return (
      <AnnyWorkspace
        userEmail={userEmail}
        userName={userName}
        initialPrompt={activePromptHint || undefined}
        onToggleMobileMenu={handleToggleMenu}
      />
    );
  };

  return (
    <div className="relative w-full h-full flex flex-col overflow-hidden">
      {/* Active View Component */}
      {renderActiveView()}

      {/* Global Slide-In Left Navigation Drawer */}
      <AnnySlideMenu
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        currentTab={currentTab}
        onSelectTab={handleTabChange}
        userName={userName}
        userEmail={userEmail}
      />
    </div>
  );
};

