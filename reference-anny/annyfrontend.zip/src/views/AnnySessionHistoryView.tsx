import React, { useState } from 'react';
import { MobileLogoMenu } from '../MobileLogoMenu';
import {
  History,
  Search,
  MessageSquare,
  Folder,
  Trash2,
  Download,
  Star,
  Clock,
  Sparkles,
  ArrowRight,
  Filter,
  MoreVertical,
  Calendar
} from 'lucide-react';

interface AnnySessionHistoryViewProps {
  onToggleMobileMenu?: () => void;
  onSelectSession?: (sessionId: string) => void;
}

export const AnnySessionHistoryView: React.FC<AnnySessionHistoryViewProps> = ({
  onToggleMobileMenu,
  onSelectSession,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'starred' | 'code' | 'design'>('all');

  const sessionGroups = [
    {
      groupName: 'Today',
      sessions: [
        {
          id: 's-1',
          title: 'Full-Stack React & Node E-Commerce Build',
          preview: 'I have generated the responsive storefront with cart management...',
          date: '08:14 PM',
          model: 'G-Ai 3.6 Omni',
          messagesCount: 18,
          starred: true,
          category: 'code',
        },
        {
          id: 's-2',
          title: 'Deep Research on Quantum Computing Architectures',
          preview: 'Summary of fault-tolerant topological qubits and hardware roadmap...',
          date: '04:30 PM',
          model: 'G-Ai 3.6 Omni',
          messagesCount: 12,
          starred: false,
          category: 'design',
        },
      ],
    },
    {
      groupName: 'Yesterday',
      sessions: [
        {
          id: 's-3',
          title: 'Cyberpunk UI/UX Component Library',
          preview: 'Glassmorphism dark theme tokens with neon cyan accents...',
          date: 'Yesterday, 10:15 PM',
          model: 'Claude 3.5 Sonnet',
          messagesCount: 24,
          starred: true,
          category: 'design',
        },
        {
          id: 's-4',
          title: 'REST API & Express Routing Refactor',
          preview: 'Modularized endpoint routes and optimized middleware stack...',
          date: 'Yesterday, 03:20 PM',
          model: 'Gemini 1.5 Pro',
          messagesCount: 9,
          starred: false,
          category: 'code',
        },
      ],
    },
    {
      groupName: 'Previous 7 Days',
      sessions: [
        {
          id: 's-5',
          title: 'Mobile Fitness Tracker App Wireframe',
          preview: 'Created React Native mobile layouts and step counter hooks...',
          date: '3 days ago',
          model: 'G-Ai 3.6 Omni',
          messagesCount: 31,
          starred: false,
          category: 'code',
        },
        {
          id: 's-6',
          title: 'Multi-Agent Autonomous Workflow Design',
          preview: 'Architected message bus and state synchronization between agents...',
          date: '5 days ago',
          model: 'DeepSeek R1',
          messagesCount: 15,
          starred: true,
          category: 'design',
        },
      ],
    },
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#040612] text-slate-100 overflow-y-auto p-4 sm:p-6 lg:p-8 custom-scrollbar">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <MobileLogoMenu onToggleMobileMenu={onToggleMobileMenu} />
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
              Anny Application
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1 flex items-center gap-2.5">
            <History className="w-7 h-7 text-cyan-400" />
            Session History
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Browse and manage all conversation history organized by date and projects.
          </p>
        </div>

        <button className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-300 bg-[#0a0f2c] border border-white/10 hover:text-white hover:bg-white/5 transition-colors cursor-pointer">
          <Download className="w-4 h-4 text-cyan-400" />
          <span>Export History</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search chat sessions..."
            className="w-full bg-[#090d28] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
              activeFilter === 'all'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'bg-[#0a0e2a] text-slate-400 border border-white/5 hover:text-white'
            }`}
          >
            All Sessions
          </button>
          <button
            onClick={() => setActiveFilter('starred')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all flex items-center gap-1.5 ${
              activeFilter === 'starred'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-[#0a0e2a] text-slate-400 border border-white/5 hover:text-white'
            }`}
          >
            <Star className="w-3.5 h-3.5 fill-amber-400/20 text-amber-400" />
            Starred
          </button>
        </div>
      </div>

      {/* Session Groups List */}
      <div className="space-y-8">
        {sessionGroups.map((group) => {
          const filteredSessions = group.sessions.filter((s) => {
            const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              s.preview.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesStar = activeFilter === 'starred' ? s.starred : true;
            return matchesSearch && matchesStar;
          });

          if (filteredSessions.length === 0) return null;

          return (
            <div key={group.groupName} className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>{group.groupName}</span>
                <span className="text-slate-600 font-mono">({filteredSessions.length})</span>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {filteredSessions.map((session) => (
                  <div
                    key={session.id}
                    onClick={() => onSelectSession && onSelectSession(session.id)}
                    className="bg-[#080b22] border border-white/10 hover:border-cyan-500/40 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all hover:bg-[#0a0e2d] cursor-pointer group"
                  >
                    <div className="flex items-start gap-3.5 min-w-0">
                      <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors truncate">
                            {session.title}
                          </h3>
                          {session.starred && (
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-1 truncate max-w-2xl">
                          {session.preview}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 border-t sm:border-t-0 border-white/5 pt-2 sm:pt-0">
                      <div className="flex items-center gap-3 text-right">
                        <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                          {session.model}
                        </span>
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-cyan-400" />
                          {session.date}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        <button className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <ArrowRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform ml-1" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
