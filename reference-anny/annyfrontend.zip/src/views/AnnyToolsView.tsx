import React, { useState } from 'react';
import { MobileLogoMenu } from '../MobileLogoMenu';
import {
  Wrench,
  Globe,
  Smartphone,
  Monitor,
  Database,
  Code2,
  Layout,
  Image as ImageIcon,
  Video,
  Music,
  FileText,
  Mic,
  Eye,
  Search,
  Sparkles,
  ArrowRight,
  Zap
} from 'lucide-react';

interface AnnyToolsViewProps {
  onToggleMobileMenu?: () => void;
  onOpenTool?: (toolName: string, promptHint?: string) => void;
}

export const AnnyToolsView: React.FC<AnnyToolsViewProps> = ({
  onToggleMobileMenu,
  onOpenTool,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const tools = [
    {
      id: 'tool-1',
      name: 'Website Builder',
      category: 'Software Engineering',
      description: 'Generates full-stack single-page websites, landing pages, and interactive dashboards with live preview.',
      icon: Globe,
      color: 'from-cyan-500 to-blue-600',
      promptHint: 'Build a responsive SaaS landing page with dark glassmorphic design and pricing tiers',
    },
    {
      id: 'tool-2',
      name: 'Mobile App Builder',
      category: 'Software Engineering',
      description: 'Designs mobile application interfaces and React Native components with phone viewports.',
      icon: Smartphone,
      color: 'from-purple-500 to-indigo-600',
      promptHint: 'Build a React Native fitness tracking mobile app interface with step progress charts',
    },
    {
      id: 'tool-3',
      name: 'Desktop App Builder',
      category: 'Software Engineering',
      description: 'Creates cross-platform desktop UI layouts (Tauri / Electron) with native title bars and sidebars.',
      icon: Monitor,
      color: 'from-emerald-500 to-teal-600',
      promptHint: 'Build a desktop audio workstation UI with waveform visualization and track controls',
    },
    {
      id: 'tool-4',
      name: 'Database Builder',
      category: 'Backend & Data',
      description: 'Designs PostgreSQL schemas, DDL scripts, ORM models, and database admin panels.',
      icon: Database,
      color: 'from-amber-500 to-orange-600',
      promptHint: 'Design a PostgreSQL database schema for an e-commerce platform with users, orders, and products',
    },
    {
      id: 'tool-5',
      name: 'Image Generator',
      category: 'Creative Media',
      description: 'Generates photorealistic images, 3D graphics, vector icons, and UI background assets using FLUX.1.',
      icon: ImageIcon,
      color: 'from-fuchsia-500 to-pink-600',
      promptHint: 'Generate a futuristic cybernetic neon logo avatar with glowing electric cyan lights',
    },
    {
      id: 'tool-6',
      name: 'Music & Audio Generator',
      category: 'Creative Media',
      description: 'Synthesizes ambient music tracks, sound effects, and voiceovers for videos and apps.',
      icon: Music,
      color: 'from-rose-500 to-red-600',
      promptHint: 'Generate an atmospheric synthwave chill background beat for a coding stream',
    },
    {
      id: 'tool-7',
      name: 'Voice AI',
      category: 'Multimodal AI',
      description: 'Real-time conversational voice mode with low-latency audio input and speech synthesis.',
      icon: Mic,
      color: 'from-blue-500 to-cyan-500',
      promptHint: 'Start a voice conversation with Anny about my software architecture',
    },
    {
      id: 'tool-8',
      name: 'Vision AI',
      category: 'Multimodal AI',
      description: 'Upload screenshots, mockups, or diagrams to convert UI designs directly into working code.',
      icon: Eye,
      color: 'from-teal-500 to-emerald-600',
      promptHint: 'Analyze this screenshot and convert it into a clean Tailwind CSS React component',
    },
    {
      id: 'tool-9',
      name: 'Deep Research Agent',
      category: 'Research & Knowledge',
      description: 'Autonomous multi-step web search agent for thorough technical investigations and summaries.',
      icon: Search,
      color: 'from-indigo-500 to-purple-600',
      promptHint: 'Perform deep research on state-of-the-art WebAssembly compilers and micro-VM runtimes',
    },
  ];

  const filteredTools = tools.filter((t) =>
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col h-full bg-[#040612] text-slate-100 overflow-y-auto p-4 sm:p-6 lg:p-8 custom-scrollbar">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <MobileLogoMenu onToggleMobileMenu={onToggleMobileMenu} />
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
              Anny Application
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1 flex items-center gap-2.5">
            <Wrench className="w-7 h-7 text-cyan-400" />
            AI Tools & Capabilities
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Access Anny's suite of autonomous builders, multimodal generators, and research engines.
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md mb-6">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search AI tools & capabilities..."
          className="w-full bg-[#090d28] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
        />
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTools.map((tool) => {
          const IconComp = tool.icon;
          return (
            <div
              key={tool.id}
              className="bg-[#080b22] border border-white/10 hover:border-cyan-500/40 rounded-2xl p-5 flex flex-col justify-between transition-all hover:shadow-[0_0_25px_rgba(0,229,255,0.15)] group cursor-pointer"
              onClick={() => onOpenTool && onOpenTool(tool.name, tool.promptHint)}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center text-white shadow-lg shrink-0`}>
                    <IconComp className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono font-semibold text-slate-400 bg-white/5 px-2 py-0.5 rounded">
                    {tool.category}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {tool.name}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {tool.description}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 mt-5 flex items-center justify-between">
                <span className="text-[11px] text-cyan-400 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                  Launch Tool <ArrowRight className="w-3.5 h-3.5" />
                </span>
                <Sparkles className="w-4 h-4 text-cyan-400/40 group-hover:text-cyan-400 transition-colors" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
