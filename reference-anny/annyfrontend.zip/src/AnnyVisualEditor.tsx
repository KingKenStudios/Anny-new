import React, { useState } from 'react';
import {
  Sparkles,
  Search,
  Monitor,
  Tablet,
  Smartphone,
  RotateCcw,
  RotateCw,
  MoreVertical,
  Pencil,
  MousePointer,
  Move,
  Type,
  Image as ImageIcon,
  Square,
  LayoutGrid,
  X,
  ChevronDown,
  ChevronRight,
  Eye,
  EyeOff,
  Trash2,
  Lock,
  GripVertical,
  ShoppingBag,
  User,
  ShoppingCart,
  ArrowRight,
  Headphones,
  Check,
  Plus,
  Wand2,
  Palette,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  ArrowLeft,
  Maximize2,
  Share2,
  Zap,
  Layers,
  SlidersHorizontal,
  Folder,
  Sliders,
  CheckCircle2,
} from 'lucide-react';

interface AnnyVisualEditorProps {
  userEmail?: string;
  userName?: string;
  onBackToWorkspace?: () => void;
  onBackToSplitView?: () => void;
}

export const AnnyVisualEditor: React.FC<AnnyVisualEditorProps> = ({
  userEmail = 'amazonpromo234@gmail.com',
  userName = 'Akin Kehinde',
  onBackToWorkspace,
  onBackToSplitView,
}) => {
  // Top level controls
  const [deviceViewport, setDeviceViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeTool, setActiveTool] = useState<'select' | 'pen' | 'move' | 'text' | 'image' | 'button' | 'shape' | 'section'>('pen');
  const [isPenToolActive, setIsPenToolActive] = useState(true);
  
  // Pen tool settings
  const [selectedColor, setSelectedColor] = useState('#9333ea');
  const [strokeWidth, setStrokeWidth] = useState('2px');

  // Canvas content state (editable live)
  const [heroTitle, setHeroTitle] = useState('Elevate Your Shopping Experience');
  const [heroSubtitle, setHeroSubtitle] = useState('Discover premium products with exceptional quality and unbeatable prices.');
  const [selectedElement, setSelectedElement] = useState<'hero-title' | 'hero-section' | 'header' | 'categories'>('hero-title');
  
  // AI Panel states
  const [aiRewriteText, setAiRewriteText] = useState('Elevate Your Shopping Experience');
  const [rewriteTone, setRewriteTone] = useState('Professional');
  const [rewriteStyle, setRewriteStyle] = useState('Modern');
  const [aiBuilderPrompt, setAiBuilderPrompt] = useState('Create a modern hero section for an e-commerce website');
  const [isRewriting, setIsRewriting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Property Inspector states
  const [activeInspectorTab, setActiveInspectorTab] = useState<'design' | 'layout' | 'advanced'>('design');
  const [gradientOverlay, setGradientOverlay] = useState(true);
  const [sectionOpacity, setSectionOpacity] = useState(60);
  const [paddingTop, setPaddingTop] = useState(80);
  const [paddingBottom, setPaddingBottom] = useState(80);
  const [paddingLeft, setPaddingLeft] = useState(80);
  const [paddingRight, setPaddingRight] = useState(80);
  const [alignment, setAlignment] = useState<'left' | 'center' | 'right' | 'justify'>('left');
  
  // Element visibility
  const [elementVisibility, setElementVisibility] = useState({
    heading: true,
    text: true,
    buttons: true,
    image: true,
  });

  // Floating Navigator State
  const [showNavigator, setShowNavigator] = useState(true);
  const [expandedNodes, setExpandedNodes] = useState({
    body: true,
    hero: true,
  });

  // Notification for Publish
  const [publishSuccess, setPublishSuccess] = useState(false);

  const colors = [
    { name: 'White', value: '#ffffff' },
    { name: 'Cyan', value: '#06b6d4' },
    { name: 'Blue', value: '#3b82f6' },
    { name: 'Green', value: '#22c55e' },
    { name: 'Orange', value: '#f97316' },
    { name: 'Pink', value: '#ec4899' },
    { name: 'Purple', value: '#9333ea' },
  ];

  const handleRewrite = () => {
    setIsRewriting(true);
    setTimeout(() => {
      const rewrites: Record<string, string> = {
        Professional: 'Transform Your Digital Shopping Journey',
        Modern: 'Elevate Your Shopping Experience',
        Casual: 'Find Products You\'ll Absolutely Love',
        Persuasive: 'Discover Unmatched Excellence in Every Purchase',
      };
      const newText = rewrites[rewriteTone] || 'Elevate Your Shopping Experience';
      setHeroTitle(newText);
      setAiRewriteText(newText);
      setIsRewriting(false);
    }, 600);
  };

  const handleGenerateSection = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
    }, 800);
  };

  const handlePublish = () => {
    setPublishSuccess(true);
    setTimeout(() => setPublishSuccess(false), 3000);
  };

  const toggleVisibility = (key: keyof typeof elementVisibility) => {
    setElementVisibility((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="flex-1 flex flex-col h-full w-full overflow-hidden bg-[#030511] text-slate-100 relative select-none">
      {/* Top Header Bar */}
      <header className="h-14 bg-[#060818]/90 backdrop-blur-md border-b border-white/10 flex items-center justify-between px-4 z-40 shrink-0 gap-4">
        {/* Left Project Info & Navigation */}
        <div className="flex items-center gap-3">
          {onBackToSplitView ? (
            <button
              onClick={onBackToSplitView}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 border border-white/10 transition-all cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-slate-400" />
              <span>Back to Builder</span>
            </button>
          ) : onBackToWorkspace ? (
            <button
              onClick={onBackToWorkspace}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 border border-white/10 transition-all cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-slate-400" />
              <span>Workspace</span>
            </button>
          ) : null}

          <div className="h-4 w-px bg-white/10 hidden sm:block" />

          <button className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400">
            <Search className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-white/5 border border-white/10 text-xs font-semibold">
            <span className="text-white">E-Commerce Website</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
            <span className="ml-1 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">Live</span>
          </div>
        </div>

        {/* Center Viewport Switcher */}
        <div className="hidden md:flex items-center gap-1 bg-[#0a0d28] p-1 rounded-xl border border-white/10">
          <button
            onClick={() => setDeviceViewport('desktop')}
            className={`p-1.5 rounded-lg transition-all cursor-pointer ${
              deviceViewport === 'desktop' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Desktop View"
          >
            <Monitor className="w-4 h-4" />
          </button>
          <button
            onClick={() => setDeviceViewport('tablet')}
            className={`p-1.5 rounded-lg transition-all cursor-pointer ${
              deviceViewport === 'tablet' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Tablet View"
          >
            <Tablet className="w-4 h-4" />
          </button>
          <button
            onClick={() => setDeviceViewport('mobile')}
            className={`p-1.5 rounded-lg transition-all cursor-pointer ${
              deviceViewport === 'mobile' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Mobile View"
          >
            <Smartphone className="w-4 h-4" />
          </button>
        </div>

        {/* Right Actions (Undo, Redo, Preview, Publish) */}
        <div className="flex items-center gap-2.5">
          <button className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer">
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer">
            <RotateCw className="w-3.5 h-3.5" />
          </button>

          <button className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-200 transition-all cursor-pointer">
            Preview
          </button>

          <button
            onClick={handlePublish}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:brightness-110 text-white text-xs font-bold shadow-lg shadow-purple-600/20 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Publish</span>
          </button>

          <button className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400">
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Floating Main Design Toolbar (Sub-Header Dock) */}
      <div className="py-2 bg-[#050716] border-b border-white/10 flex items-center justify-center shrink-0 z-30">
        <div className="bg-[#080b22]/90 backdrop-blur-md rounded-2xl border border-white/15 p-1 flex items-center gap-1 shadow-2xl">
          <button
            onClick={() => setActiveTool('select')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'select' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <MousePointer className="w-3.5 h-3.5" />
            <span>Select</span>
          </button>

          <button
            onClick={() => {
              setActiveTool('pen');
              setIsPenToolActive(true);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'pen' ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Pencil className="w-3.5 h-3.5 text-purple-200" />
            <span>Pen</span>
          </button>

          <button
            onClick={() => setActiveTool('move')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'move' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Move className="w-3.5 h-3.5" />
            <span>Move</span>
          </button>

          <button
            onClick={() => setActiveTool('text')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'text' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Type className="w-3.5 h-3.5" />
            <span>Text</span>
          </button>

          <button
            onClick={() => setActiveTool('image')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'image' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Image</span>
          </button>

          <button
            onClick={() => setActiveTool('button')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'button' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <MousePointer className="w-3.5 h-3.5" />
            <span>Button</span>
          </button>

          <button
            onClick={() => setActiveTool('shape')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'shape' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Square className="w-3.5 h-3.5" />
            <span>Shape</span>
          </button>

          <button
            onClick={() => setActiveTool('section')}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTool === 'section' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Section</span>
          </button>

          <span className="text-slate-600 px-1">... More</span>
        </div>
      </div>

      {/* Main Workspace Body (3-Column Layout) */}
      <div className="flex-1 flex overflow-hidden min-h-0 relative">
        {/* ========================================= */}
        {/* LEFT COLUMN: AI Panels (AI Rewrite + AI Builder) */}
        {/* ========================================= */}
        <div className="w-[270px] xl:w-[290px] bg-[#06081a] border-r border-white/10 flex flex-col p-3 gap-3 overflow-y-auto shrink-0 z-20">
          {/* AI Rewrite Panel */}
          <div className="bg-[#0a0d2a] border border-purple-500/30 rounded-2xl p-3.5 shadow-xl flex flex-col gap-3 relative">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>AI Rewrite (Pen Tool)</span>
              </span>
              <button className="text-slate-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-[11px] text-slate-400 leading-snug">
              Rewrite any text on your website
            </p>

            <div className="bg-[#050718] border border-purple-500/50 focus-within:border-purple-400 rounded-xl p-2.5 transition-all shadow-inner">
              <textarea
                value={aiRewriteText}
                onChange={(e) => {
                  setAiRewriteText(e.target.value);
                  setHeroTitle(e.target.value);
                }}
                rows={3}
                className="w-full bg-transparent border-none outline-none text-xs text-white resize-none font-medium leading-relaxed"
              />
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex flex-col gap-1">
                <label className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Tone</label>
                <select
                  value={rewriteTone}
                  onChange={(e) => setRewriteTone(e.target.value)}
                  className="bg-[#050718] border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none cursor-pointer"
                >
                  <option value="Professional">Professional</option>
                  <option value="Modern">Modern</option>
                  <option value="Casual">Casual</option>
                  <option value="Persuasive">Persuasive</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Style</label>
                <select
                  value={rewriteStyle}
                  onChange={(e) => setRewriteStyle(e.target.value)}
                  className="bg-[#050718] border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none cursor-pointer"
                >
                  <option value="Modern">Modern</option>
                  <option value="Bold">Bold</option>
                  <option value="Minimal">Minimal</option>
                  <option value="Luxury">Luxury</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleRewrite}
              disabled={isRewriting}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:brightness-110 text-white text-xs font-bold shadow-md shadow-purple-600/20 transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-200" />
              <span>{isRewriting ? 'Rewriting...' : 'Rewrite with AI'}</span>
            </button>
          </div>

          {/* AI Builder Panel */}
          <div className="bg-[#0a0d2a] border border-white/10 rounded-2xl p-3.5 shadow-xl flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">AI Builder</span>
              <button className="text-slate-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-[11px] text-slate-400 leading-snug">
              What do you want to build?
            </p>

            <div className="bg-[#050718] border border-purple-500/40 focus-within:border-purple-400 rounded-xl p-2.5 transition-all">
              <textarea
                value={aiBuilderPrompt}
                onChange={(e) => setAiBuilderPrompt(e.target.value)}
                rows={3}
                className="w-full bg-transparent border-none outline-none text-xs text-white resize-none font-medium leading-relaxed"
                placeholder="Describe a section or feature to generate..."
              />
            </div>

            <button
              onClick={handleGenerateSection}
              disabled={isGenerating}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:brightness-110 text-white text-xs font-bold shadow-md shadow-purple-600/20 transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-200" />
              <span>{isGenerating ? 'Generating...' : 'Generate Section'}</span>
            </button>

            <div className="flex flex-col gap-1.5 pt-1">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Suggestions</span>
              <button
                onClick={() => setAiBuilderPrompt('Create a product grid for e-commerce store')}
                className="text-left text-[11px] text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl px-2.5 py-1.5 transition-all cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3 h-3 text-purple-400" />
                <span>Create a product grid</span>
              </button>

              <button
                onClick={() => setAiBuilderPrompt('Add testimonials section with user reviews')}
                className="text-left text-[11px] text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl px-2.5 py-1.5 transition-all cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3 h-3 text-purple-400" />
                <span>Add testimonials section</span>
              </button>

              <button
                onClick={() => setAiBuilderPrompt('Create a newsletter subscription section')}
                className="text-left text-[11px] text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl px-2.5 py-1.5 transition-all cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3 h-3 text-purple-400" />
                <span>Create a newsletter section</span>
              </button>
            </div>
          </div>
        </div>

        {/* ========================================= */}
        {/* CENTER COLUMN: Visual Design Canvas Surface */}
        {/* ========================================= */}
        <div className="flex-1 bg-[#02040d] overflow-y-auto p-4 md:p-6 flex flex-col items-center relative min-w-0">
          {/* Floating Pen Tool Active Toolbar (Directly above hero heading canvas box) */}
          <div className="mb-3 bg-[#0c0e2a] border border-purple-500/50 shadow-2xl rounded-2xl p-2.5 flex items-center gap-3 z-30 transition-all">
            <div className="flex items-center gap-2 bg-purple-600/30 border border-purple-500/50 px-2.5 py-1 rounded-xl text-xs font-semibold text-purple-200">
              <Pencil className="w-3.5 h-3.5 text-purple-400" />
              <span>Pen Tool Active</span>
            </div>

            <button
              onClick={() => setIsPenToolActive(false)}
              className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-xs text-slate-200 font-semibold cursor-pointer"
            >
              Done
            </button>

            <div className="h-4 w-px bg-white/15" />

            {/* Color Swatches */}
            <div className="flex items-center gap-1.5">
              {colors.map((c) => (
                <button
                  key={c.value}
                  onClick={() => setSelectedColor(c.value)}
                  style={{ backgroundColor: c.value }}
                  className={`w-4 h-4 rounded-full border transition-transform cursor-pointer ${
                    selectedColor === c.value ? 'scale-125 border-white ring-2 ring-purple-500' : 'border-transparent hover:scale-110'
                  }`}
                  title={c.name}
                />
              ))}
            </div>

            <div className="h-4 w-px bg-white/15" />

            {/* Stroke selector */}
            <select
              value={strokeWidth}
              onChange={(e) => setStrokeWidth(e.target.value)}
              className="bg-[#050718] border border-white/10 rounded-lg px-2 py-0.5 text-xs text-slate-300 outline-none cursor-pointer"
            >
              <option value="1px">1px</option>
              <option value="2px">2px</option>
              <option value="3px">3px</option>
              <option value="4px">4px</option>
            </select>
          </div>

          {/* Interactive Web Page Canvas Container */}
          <div
            className={`w-full transition-all duration-300 bg-[#06081d] border border-white/10 rounded-3xl shadow-2xl overflow-hidden relative ${
              deviceViewport === 'desktop'
                ? 'max-w-4xl'
                : deviceViewport === 'tablet'
                ? 'max-w-xl'
                : 'max-w-xs'
            }`}
          >
            {/* Visual Editor AI Mockup Banner Notice */}
            <div className="bg-purple-950/90 border-b border-purple-500/40 px-4 py-2 flex items-center justify-between text-xs text-purple-200 z-30">
              <div className="flex items-center gap-2 font-medium">
                <span className="px-1.5 py-0.5 rounded bg-purple-500 text-white font-extrabold text-[10px] uppercase tracking-wider">
                  VISUAL EDITOR MOCKUP
                </span>
                <span>[AI Directive: Replace all visual canvas elements with real API endpoints]</span>
              </div>
              <span className="text-[10px] text-purple-300/80 font-mono hidden sm:inline-block">Backend required for persistence</span>
            </div>

            {/* Nexora Header */}
            <header className="px-6 py-4 border-b border-white/10 flex items-center justify-between gap-4 bg-[#080b26]/80 backdrop-blur-md">
              <div className="flex items-center gap-8">
                <span className="text-xl font-extrabold tracking-widest text-white font-sans uppercase">
                  NEXORA
                </span>

                <nav className="hidden md:flex items-center gap-5 text-xs font-medium text-slate-300">
                  <span className="text-white font-semibold cursor-pointer">Home</span>
                  <span className="hover:text-white cursor-pointer">Shop</span>
                  <span className="hover:text-white cursor-pointer">Categories</span>
                  <span className="hover:text-white cursor-pointer">Deals</span>
                  <span className="hover:text-white cursor-pointer">About</span>
                </nav>
              </div>

              <div className="flex items-center gap-3 text-slate-300">
                <button className="hover:text-white">
                  <Search className="w-4 h-4" />
                </button>
                <button className="hover:text-white">
                  <User className="w-4 h-4" />
                </button>
                <div className="relative cursor-pointer">
                  <ShoppingCart className="w-4 h-4" />
                  <span className="absolute -top-1.5 -right-2 bg-purple-600 text-white text-[9px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                    3
                  </span>
                </div>
              </div>
            </header>

            {/* Hero Section Canvas Area */}
            <section
              style={{
                opacity: sectionOpacity / 100,
                paddingTop: `${paddingTop}px`,
                paddingBottom: `${paddingBottom}px`,
                paddingLeft: `${paddingLeft}px`,
                paddingRight: `${paddingRight}px`,
              }}
              className="relative overflow-hidden bg-gradient-to-br from-[#0a0d2f] via-[#070921] to-[#040515] transition-all"
            >
              {/* Background ambient lighting */}
              {gradientOverlay && (
                <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[350px] h-[350px] bg-purple-600/20 rounded-full blur-[100px] pointer-events-none" />
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center relative z-10">
                {/* Left Hero Content */}
                <div className="flex flex-col items-start gap-4 text-left">
                  <span className="px-3 py-1 rounded-full bg-purple-900/60 border border-purple-500/40 text-[10px] font-bold uppercase tracking-wider text-purple-300">
                    NEW COLLECTION
                  </span>

                  {/* ACTIVE BOUNDING BOX SELECTION FOR HERO TITLE */}
                  <div
                    onClick={() => setSelectedElement('hero-title')}
                    className={`relative w-full rounded-xl transition-all cursor-pointer p-1 ${
                      selectedElement === 'hero-title'
                        ? 'ring-2 ring-purple-500 bg-purple-500/10 shadow-lg shadow-purple-500/20'
                        : 'hover:ring-1 hover:ring-purple-400/50'
                    }`}
                  >
                    {/* Bounding box corner handles */}
                    {selectedElement === 'hero-title' && (
                      <>
                        <div className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-purple-500 border border-white rounded-sm shadow" />
                        <div className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-purple-500 border border-white rounded-sm shadow" />
                        <div className="absolute -bottom-1.5 -left-1.5 w-3 h-3 bg-purple-500 border border-white rounded-sm shadow" />
                        <div className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-purple-500 border border-white rounded-sm shadow" />

                        {/* Vector Pointer Arrow SVG from Pen Tool */}
                        <svg
                          className="absolute -top-12 -right-16 w-20 h-16 pointer-events-none z-30"
                          viewBox="0 0 100 80"
                          fill="none"
                        >
                          <path
                            d="M 10 10 C 50 10, 80 30, 85 65"
                            stroke="#c084fc"
                            strokeWidth="3"
                            strokeDasharray="4 2"
                            fill="none"
                          />
                          <polygon points="85,65 75,55 88,52" fill="#c084fc" />
                        </svg>
                      </>
                    )}

                    {elementVisibility.heading && (
                      <h1 className="text-2xl md:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-tight">
                        {heroTitle}
                      </h1>
                    )}
                  </div>

                  {elementVisibility.text && (
                    <p className="text-xs md:text-sm text-slate-300 leading-relaxed max-w-md">
                      {heroSubtitle}
                    </p>
                  )}

                  {elementVisibility.buttons && (
                    <div className="flex items-center gap-3 pt-2">
                      <button className="px-5 py-2.5 rounded-xl bg-white text-slate-900 font-bold text-xs hover:bg-slate-100 transition-all shadow-lg cursor-pointer">
                        Shop Now
                      </button>
                      <button className="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs border border-white/20 transition-all flex items-center gap-1.5 cursor-pointer">
                        <span>Explore Deals</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Right Hero Image Frame */}
                {elementVisibility.image && (
                  <div className="flex justify-center items-center relative">
                    {/* Glowing Purple Ring */}
                    <div className="w-48 h-48 md:w-60 md:h-60 rounded-full border-2 border-purple-500/60 shadow-[0_0_50px_rgba(147,51,234,0.4)] flex items-center justify-center relative bg-purple-950/20">
                      <img
                        src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80"
                        alt="Hero Product"
                        referrerPolicy="no-referrer"
                        className="w-44 h-44 object-contain drop-shadow-[0_20px_20px_rgba(0,0,0,0.8)] -rotate-12 transition-transform hover:scale-105"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-3 gap-4 mt-10 pt-6 border-t border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
                    <User className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-white">10K+</div>
                    <div className="text-[10px] text-slate-400">Happy Customers</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
                    <ShoppingBag className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-white">500+</div>
                    <div className="text-[10px] text-slate-400">Premium Products</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
                    <Headphones className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-white">24/7</div>
                    <div className="text-[10px] text-slate-400">Support</div>
                  </div>
                </div>
              </div>
            </section>

            {/* Shop by Categories Section */}
            <section className="p-6 bg-[#050718] border-t border-white/10">
              <h2 className="text-sm font-bold text-white mb-4 text-left">Shop by Categories</h2>
              <div className="grid grid-cols-5 gap-3">
                {[
                  { name: 'Electronics', img: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&q=80' },
                  { name: 'Fashion', img: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=200&q=80' },
                  { name: 'Home & Living', img: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=200&q=80' },
                  { name: 'Beauty', img: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=200&q=80' },
                  { name: 'Sports', img: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=200&q=80' },
                ].map((cat) => (
                  <div
                    key={cat.name}
                    className="bg-[#090b24] border border-white/10 rounded-2xl p-2.5 flex flex-col items-center gap-2 hover:border-purple-500/50 transition-all cursor-pointer"
                  >
                    <img src={cat.img} alt={cat.name} referrerPolicy="no-referrer" className="w-12 h-12 object-cover rounded-xl" />
                    <span className="text-[10px] font-semibold text-slate-200">{cat.name}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Floating Smart Actions Toolbar (Bottom Canvas) */}
          <div className="mt-4 bg-[#080b22]/90 backdrop-blur-md border border-white/15 rounded-2xl p-2 flex items-center gap-2 text-xs shadow-2xl z-20">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2">Smart Actions</span>
            <button className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer">
              <Sparkles className="w-3 h-3 text-purple-400" /> Redesign Section
            </button>
            <button className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer">
              <LayoutGrid className="w-3 h-3 text-blue-400" /> Improve Layout
            </button>
            <button className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer">
              <Type className="w-3 h-3 text-emerald-400" /> Write Better Copy
            </button>
            <button className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer">
              <Palette className="w-3 h-3 text-pink-400" /> Change Style
            </button>
            <button className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer">
              <Smartphone className="w-3 h-3 text-cyan-400" /> Optimize for Mobile
            </button>
          </div>

          {/* Floating Navigator Panel (Overlay on right side of canvas) */}
          {showNavigator && (
            <div className="absolute top-6 right-6 w-[210px] bg-[#080a22]/95 backdrop-blur-md border border-purple-500/30 rounded-2xl p-3 shadow-2xl text-xs z-30">
              <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
                <span className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-purple-400" />
                  <span>Navigator</span>
                </span>
                <button onClick={() => setShowNavigator(false)} className="text-slate-400 hover:text-white">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex flex-col gap-1 text-[11px] font-mono text-slate-300">
                <div className="flex items-center gap-1 py-0.5 px-1 hover:bg-white/5 rounded">
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                  <Folder className="w-3 h-3 text-blue-400" />
                  <span>Body</span>
                </div>

                <div className="pl-3 flex items-center gap-1 py-0.5 px-1 hover:bg-white/5 rounded text-slate-400">
                  <Folder className="w-3 h-3 text-slate-500" />
                  <span>Header</span>
                </div>

                <div className="pl-3 flex items-center gap-1 py-1 px-2 bg-purple-600 text-white font-semibold rounded-lg shadow">
                  <Folder className="w-3 h-3 text-purple-200" />
                  <span>Hero Section</span>
                </div>

                <div className="pl-6 flex items-center gap-1 py-0.5 px-1 text-purple-300">
                  <Type className="w-3 h-3 text-purple-400" />
                  <span>Heading</span>
                </div>

                <div className="pl-6 flex items-center gap-1 py-0.5 px-1 text-slate-400">
                  <Type className="w-3 h-3 text-slate-500" />
                  <span>Text</span>
                </div>

                <div className="pl-6 flex items-center gap-1 py-0.5 px-1 text-slate-400">
                  <MousePointer className="w-3 h-3 text-slate-500" />
                  <span>Buttons</span>
                </div>

                <div className="pl-6 flex items-center gap-1 py-0.5 px-1 text-slate-400">
                  <ImageIcon className="w-3 h-3 text-slate-500" />
                  <span>Image</span>
                </div>

                <div className="pl-3 flex items-center gap-1 py-0.5 px-1 text-slate-400">
                  <Folder className="w-3 h-3 text-slate-500" />
                  <span>Features Section</span>
                </div>

                <div className="pl-3 flex items-center gap-1 py-0.5 px-1 text-slate-400">
                  <Folder className="w-3 h-3 text-slate-500" />
                  <span>Categories Section</span>
                </div>

                <div className="pl-3 flex items-center gap-1 py-0.5 px-1 text-slate-400">
                  <Folder className="w-3 h-3 text-slate-500" />
                  <span>Footer</span>
                </div>
              </div>
            </div>
          )}

          {/* Drag & Drop Tooltip (Bottom right corner) */}
          <div className="fixed bottom-6 right-80 bg-[#0e1136] border border-white/15 rounded-2xl p-3 flex items-center gap-3 shadow-2xl z-30 pointer-events-none">
            <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Move className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className="text-xs font-bold text-white">Drag & Drop</div>
              <div className="text-[10px] text-slate-400">Move any element where you want</div>
            </div>
          </div>
        </div>

        {/* ========================================= */}
        {/* RIGHT COLUMN: Property Inspector Sidebar   */}
        {/* ========================================= */}
        <div className="w-[270px] xl:w-[290px] bg-[#06081a] border-l border-white/10 flex flex-col h-full overflow-y-auto shrink-0 text-xs text-slate-300 p-3.5 gap-4 z-20">
          {/* Section Header */}
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div>
              <div className="font-bold text-white text-xs flex items-center gap-1.5">
                <span>Section</span>
              </div>
              <div className="text-[11px] font-semibold text-slate-200 mt-0.5">Hero Section</div>
              <div className="text-[10px] text-slate-500 font-mono">ID: hero-1</div>
            </div>
            <div className="flex items-center gap-1">
              <button className="p-1 rounded hover:bg-white/10 text-slate-400">
                <Search className="w-3.5 h-3.5" />
              </button>
              <button className="p-1 rounded hover:bg-white/10 text-slate-400">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Inspector Tabs (Design, Layout, Advanced) */}
          <div className="flex items-center border-b border-white/10">
            <button
              onClick={() => setActiveInspectorTab('design')}
              className={`flex-1 py-1.5 text-center font-semibold text-xs border-b-2 transition-all cursor-pointer ${
                activeInspectorTab === 'design'
                  ? 'border-purple-500 text-purple-400'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Design
            </button>
            <button
              onClick={() => setActiveInspectorTab('layout')}
              className={`flex-1 py-1.5 text-center font-semibold text-xs border-b-2 transition-all cursor-pointer ${
                activeInspectorTab === 'layout'
                  ? 'border-purple-500 text-purple-400'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Layout
            </button>
            <button
              onClick={() => setActiveInspectorTab('advanced')}
              className={`flex-1 py-1.5 text-center font-semibold text-xs border-b-2 transition-all cursor-pointer ${
                activeInspectorTab === 'advanced'
                  ? 'border-purple-500 text-purple-400'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              Advanced
            </button>
          </div>

          {/* Style Group */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between font-bold text-white">
              <span>Style</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Background</span>
              <div className="flex items-center gap-1 bg-[#0a0d28] px-2 py-1 rounded-lg border border-white/10">
                <div className="w-3 h-3 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600" />
                <span className="text-white text-[11px] font-medium">Gradient</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Direction</span>
              <div className="w-5 h-5 rounded-full border border-purple-500/50 bg-purple-600/30 flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Overlay</span>
              <input
                type="checkbox"
                checked={gradientOverlay}
                onChange={(e) => setGradientOverlay(e.target.checked)}
                className="accent-purple-600 w-4 h-4 cursor-pointer"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Opacity</span>
                <span className="text-white font-mono">{sectionOpacity}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={sectionOpacity}
                onChange={(e) => setSectionOpacity(Number(e.target.value))}
                className="w-full accent-purple-600 cursor-pointer"
              />
            </div>
          </div>

          {/* Padding Model Box */}
          <div className="flex flex-col gap-2 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between font-bold text-white">
              <span>Padding</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </div>

            <div className="bg-[#050718] border border-white/10 rounded-2xl p-3 flex flex-col items-center gap-1 relative text-[10px] font-mono">
              <span className="text-slate-400">{paddingTop}px</span>
              <div className="w-full flex items-center justify-between px-2">
                <span className="text-slate-400">{paddingLeft}px</span>
                <div className="w-6 h-6 rounded-lg bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300">
                  <Lock className="w-3 h-3" />
                </div>
                <span className="text-slate-400">{paddingRight}px</span>
              </div>
              <span className="text-slate-400">{paddingBottom}px</span>
            </div>
          </div>

          {/* Content Group */}
          <div className="flex flex-col gap-3 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between font-bold text-white">
              <span>Content</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Width</span>
              <select className="bg-[#050718] border border-white/10 rounded-xl px-2 py-1 text-xs text-white outline-none cursor-pointer">
                <option>Full Width</option>
                <option>Boxed</option>
              </select>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Max Width</span>
              <select className="bg-[#050718] border border-white/10 rounded-xl px-2 py-1 text-xs text-white outline-none cursor-pointer">
                <option>1200px</option>
                <option>1400px</option>
                <option>100%</option>
              </select>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Alignment</span>
              <div className="flex items-center gap-1 bg-[#050718] p-1 rounded-xl border border-white/10">
                <button
                  onClick={() => setAlignment('left')}
                  className={`p-1 rounded ${alignment === 'left' ? 'bg-purple-600 text-white' : 'text-slate-400'}`}
                >
                  <AlignLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setAlignment('center')}
                  className={`p-1 rounded ${alignment === 'center' ? 'bg-purple-600 text-white' : 'text-slate-400'}`}
                >
                  <AlignCenter className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setAlignment('right')}
                  className={`p-1 rounded ${alignment === 'right' ? 'bg-purple-600 text-white' : 'text-slate-400'}`}
                >
                  <AlignRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setAlignment('justify')}
                  className={`p-1 rounded ${alignment === 'justify' ? 'bg-purple-600 text-white' : 'text-slate-400'}`}
                >
                  <AlignJustify className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Elements Section */}
          <div className="flex flex-col gap-2 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between font-bold text-white">
              <span>Elements</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </div>

            <div className="flex flex-col gap-1 text-xs">
              <div className="flex items-center justify-between bg-white/5 px-2.5 py-1.5 rounded-xl border border-white/5">
                <div className="flex items-center gap-2">
                  <GripVertical className="w-3.5 h-3.5 text-slate-500" />
                  <Type className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-white font-medium">Heading</span>
                </div>
                <button onClick={() => toggleVisibility('heading')} className="text-slate-400 hover:text-white">
                  {elementVisibility.heading ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5 text-slate-600" />}
                </button>
              </div>

              <div className="flex items-center justify-between bg-white/5 px-2.5 py-1.5 rounded-xl border border-white/5">
                <div className="flex items-center gap-2">
                  <GripVertical className="w-3.5 h-3.5 text-slate-500" />
                  <Type className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-white font-medium">Text</span>
                </div>
                <button onClick={() => toggleVisibility('text')} className="text-slate-400 hover:text-white">
                  {elementVisibility.text ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5 text-slate-600" />}
                </button>
              </div>

              <div className="flex items-center justify-between bg-white/5 px-2.5 py-1.5 rounded-xl border border-white/5">
                <div className="flex items-center gap-2">
                  <GripVertical className="w-3.5 h-3.5 text-slate-500" />
                  <MousePointer className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-white font-medium">Buttons</span>
                </div>
                <button onClick={() => toggleVisibility('buttons')} className="text-slate-400 hover:text-white">
                  {elementVisibility.buttons ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5 text-slate-600" />}
                </button>
              </div>

              <div className="flex items-center justify-between bg-white/5 px-2.5 py-1.5 rounded-xl border border-white/5">
                <div className="flex items-center gap-2">
                  <GripVertical className="w-3.5 h-3.5 text-slate-500" />
                  <ImageIcon className="w-3.5 h-3.5 text-pink-400" />
                  <span className="text-white font-medium">Image</span>
                </div>
                <button onClick={() => toggleVisibility('image')} className="text-slate-400 hover:text-white">
                  {elementVisibility.image ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5 text-slate-600" />}
                </button>
              </div>
            </div>
          </div>

          {/* Delete Section Button */}
          <div className="pt-4 border-t border-white/10 mt-auto">
            <button className="w-full py-2 rounded-xl border border-red-500/40 hover:bg-red-500/10 text-red-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer">
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Section</span>
            </button>
          </div>
        </div>
      </div>

      {/* Toast Notification on Publish */}
      {publishSuccess && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-emerald-950 border border-emerald-500/50 text-emerald-200 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 z-50 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <div className="text-xs text-left">
            <div className="font-bold text-white">Successfully Published!</div>
            <div className="text-[10px] text-emerald-300">Your visual changes are now live on your domain.</div>
          </div>
        </div>
      )}
    </div>
  );
};
