import React from 'react';
import akinLogoImg from './assets/logo.png';

const akinLogo = akinLogoImg || '/logo.png';

interface AnnyLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
}

export const AnnyLogo: React.FC<AnnyLogoProps> = ({ size = 'md', showTagline = true }) => {
  const heightClass = size === 'sm' ? 'h-8 sm:h-10' : size === 'lg' ? 'h-16 sm:h-20' : 'h-12 sm:h-14';

  return (
    <div className="flex flex-col items-center justify-center select-none">
      <div className="relative flex items-center justify-center group">
        {/* Animated Rotating Equalizer Ring from Login Page */}
        <div className="absolute -inset-3 pointer-events-none flex items-center justify-center">
          <svg className="w-16 h-16 sm:w-20 sm:h-20 animate-ring-rotate" viewBox="0 0 500 500" fill="none">
            <defs>
              <rect id="akinLogoTick" x="242" y="6" width="16" height="40" rx="8" />
            </defs>
            <g>
              <use href="#akinLogoTick" transform="rotate(0 250 250)" style={{ fill: 'hsl(315, 100%, 60%)' }} />
              <use href="#akinLogoTick" transform="rotate(30 250 250)" style={{ fill: 'hsl(300, 100%, 60%)' }} />
              <use href="#akinLogoTick" transform="rotate(60 250 250)" style={{ fill: 'hsl(285, 100%, 60%)' }} />
              <use href="#akinLogoTick" transform="rotate(90 250 250)" style={{ fill: 'hsl(270, 100%, 62%)' }} />
              <use href="#akinLogoTick" transform="rotate(120 250 250)" style={{ fill: 'hsl(255, 100%, 62%)' }} />
              <use href="#akinLogoTick" transform="rotate(150 250 250)" style={{ fill: 'hsl(240, 100%, 62%)' }} />
              <use href="#akinLogoTick" transform="rotate(180 250 250)" style={{ fill: 'hsl(225, 100%, 58%)' }} />
              <use href="#akinLogoTick" transform="rotate(210 250 250)" style={{ fill: 'hsl(210, 100%, 58%)' }} />
              <use href="#akinLogoTick" transform="rotate(240 250 250)" style={{ fill: 'hsl(195, 100%, 58%)' }} />
              <use href="#akinLogoTick" transform="rotate(270 250 250)" style={{ fill: 'hsl(180, 100%, 56%)' }} />
              <use href="#akinLogoTick" transform="rotate(300 250 250)" style={{ fill: 'hsl(165, 100%, 56%)' }} />
              <use href="#akinLogoTick" transform="rotate(330 250 250)" style={{ fill: 'hsl(150, 100%, 56%)' }} />
            </g>
            <circle cx="250" cy="250" r="202" stroke="rgba(0, 210, 255, 0.5)" strokeWidth="8" strokeDasharray="16 28" />
            <circle cx="250" cy="250" r="244" stroke="rgba(240, 80, 216, 0.45)" strokeWidth="6" strokeDasharray="12 24" />
          </svg>
        </div>

        <img
          src={akinLogo}
          alt="Anny Logo"
          loading="eager"
          fetchpriority="high"
          decoding="sync"
          referrerPolicy="no-referrer"
          className={`${heightClass} w-auto object-contain filter drop-shadow-[0_0_20px_rgba(0,229,255,0.6)] hover:drop-shadow-[0_0_30px_rgba(217,70,239,0.8)] transition-all duration-300 transform group-hover:scale-105 relative z-10`}
        />
      </div>

      {showTagline && (
        <span className="text-xl sm:text-2xl font-black font-heading animate-aios-shift tracking-wider mt-2.5 drop-shadow-[0_0_12px_rgba(0,229,255,0.6)]">
          Anny
        </span>
      )}
    </div>
  );
};
