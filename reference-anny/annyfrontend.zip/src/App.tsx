import React from 'react';
import { AnnyApp } from './AnnyApp';

function App() {
  return (
    <div className="w-full h-screen h-[100dvh] bg-[#030511] text-white overflow-hidden flex flex-col">
      <AnnyApp />
    </div>
  );
}

export default App;
